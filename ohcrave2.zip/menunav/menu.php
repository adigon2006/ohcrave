<ul class="nav navbar-nav">
                   <!-- <li><a href="../index.html">Logo</a>
                    </li> -->
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Explore<span class="caret"></span></a>
                        <ul class="dropdown-menu" role="menu">
                            <li class="dropdown-header">Private User Pages</li>
                            <li><a href="../home/">Timeline</a>
                            </li>
                            <li><a href="../privateprofile">About Me</a>
                            </li>
                            <li><a href="../followers">Followers</a>
                            </li>
                            <li><a href="../activeplans">My Active Plans</a>
                            </li>
                            <li><a href="../mybox">My Box</a>
                            </li>
                            <li><a href="../uploadprofilepix">Change Profile Pix</a>
                            </li>
                            <li><a href="../uploadprofilepix">Change Password</a>
                            </li>

                          <!--   <li class="dropdown-header">Private User Pages</li>
                            <li><a href="user-private-messages.html">Messages</a>
                            </li>
                            <li class="active"><a href="user-private-profile.html">Profile</a>
                            </li>
                            <li><a href="user-private-timeline.html">Timeline</a>
                            </li>
                            <li><a href="user-private-users.html">Friends</a>
                            </li> -->
                        </ul>
                    </li>
                  
                </ul>