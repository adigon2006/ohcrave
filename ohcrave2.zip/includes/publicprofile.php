<?php
require_once 'Mydbhandler.php';
$dbhandle = new Mydbhandler();
$dbhandle->sessionstart();
$myid = $_SESSION['myusrid'];
$dbhandle->checkLoggedInStatus();
$dbhandle->confirmCheckIfNotExist($myid);
//echo "gshfbjdbfbdhbfjbdkbfkjdbjfbdjbfjbdjfbjdbfjdjbfjdbjfbjdfkdj";
//echo $dbhandle->convert($_GET['nvsp'],$dbhandle->secretKey());
if(!isset($_GET['ssvgdvvdsvdvvhjsbddjjkdbhbsbbdjbbsbdsbbdbb1234251r2yt3g2ghvhgavdvsdvsdbds192']))
{
$dbhandle->redirect_to('../pagenotfound/');
}
else if(isset($_GET['ssvgdvvdsvdvvhjsbddjjkdbhbsbbdjbbsbdsbbdbb1234251r2yt3g2ghvhgavdvsdvsdbds192']) && $_GET['ssvgdvvdsvdvvhjsbddjjkdbhbsbbdjbbsbdsbbdbb1234251r2yt3g2ghvhgavdvsdvsdbds192']== "")
{
 $dbhandle->redirect_to('../pagenotfound/');   
}
else if($dbhandle->confirmCheckIfNotExist($_GET['ssvgdvvdsvdvvhjsbddjjkdbhbsbbdjbbsbdsbbdbb1234251r2yt3g2ghvhgavdvsdvsdbds192']))
{
 $dbhandle->redirect_to('../pagenotfound/');
}

?>
