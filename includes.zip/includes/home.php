<?php
require_once 'Mydbhandler.php';
$dbhandle = new Mydbhandler();
$dbhandle->sessionstart();
$myid = $_SESSION['myusrid'];
$dbhandle->checkLoggedInStatus();
$dbhandle->InitializeFirstTime($myid);
$homeplans  = $dbhandle->getActiveHomePlans();
$lasttenusers = $dbhandle->theLastTenUsers();
$dbhandle->SendEmail('info@ohcrave.com','OHCrave','adigon2006@gmail.com','Test Email','Well this a test email to check if the email set up is working perfectly fine');
?>

