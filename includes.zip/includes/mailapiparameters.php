<?php
define('SMTP_USERNAME','AKIAJZ77YIIF2NSUAE3Q');
define('SMTP_PASSWORD','As8IXRqryAhkE52X2iFoapr2vBz2u4f/UWuOt4NT9HyO');
define('SMTP_HOST','tls://email-smtp.us-west-2.amazonaws.com');
define('SMTP_PORT',465);
?>