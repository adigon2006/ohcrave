// JavaScript Document
$(document).ready(function(e) {

// post a plan
$('#postplan').click(function(e) {
myplan = $('#myplan').val();
if(myplan == "")
{

}
else if(myplan != "")
{
$.post('../snippets/postmyplan.php',{'myplan':myplan},function(data)
{
$('#activehomeplans').hide().prepend(data).fadeIn("slow");  
$('#myplan').val("");	
});
}
  
}); 



$('.addcomment').each(function(index, element) {
$('.addcomment:eq('+index+')').click(function(e) {
e.preventDefault();	
plancomment = $('.plancomment:eq('+index+')').val();
planid = $('.planids:eq('+index+')').val();
//$('.comments:eq('+index+')').prepend('<li>'+plancomment+planid+'</li>');
if(plancomment == '')
{
	
}
else if(plancomment != '')
{
$('.plancomment:eq('+index+')').val(""); 
$.post('../snippets/addcomment.php',{'planid':planid,'plancomment':plancomment},function(data){
$('.comments:eq('+index+')').hide().fadeIn(2000).prepend(data);
$.get('../snippets/getcommentscount.php',{'planid':planid},function(data){$('.countcomments:eq('+index+')').html(data);});
});
}
});	
/*plancomment = $('.plancomment:eq('+index+')').val();    

$.post('../snippets/addcomment.php','',function(data){$('.comment').hide().append(data).slideDown('2000');});*/
});


/*setInterval(function()
{
$.get('../snippets/gethomeplans.php',"",function(data)
{
$('#activehomeplans').html(data);	
});	
},3000);   */

//crave a particular plan as required
$('.craveplan').each(function(index, element) {

$('.craveplan:eq('+index+')').click(function(e) {
planid = $('.planids:eq('+index+')').val();
$.post('../snippets/addcraver.php',{'planid':planid},function(data)
{
if(data == 'added')
{//$('.cravebox').html("hjhknjnkj");
	$('.cravebox:eq('+index+')').html('<i title="Uncrave This Plan" style="color:#F3565D;" class="cravestyle fa fa-camera uncraveplan"> crave </i><i style="display:none;" title="Crave this Plan" class="cravestyle fa fa-camera craveplan"> crave </i><script src="../myscript/home.js"></script>');
/*$('.craveplan:eq('+index+')').removeClass('fa-heart');
$('.craveplan:eq('+index+')').addClass('uncraveplan');
$('.craveplan:eq('+index+')').addClass('fa-thumbs-down');
$('.craveplan:eq('+index+')').attr("title","Uncrave this plan");
$('.craveplan:eq('+index+')').html(' Uncrave you craved this plan');
$('.craveplan:eq('+index+')').removeClass('craveplan');*/	
/*$.get('../snippets/countcravers.php',{'planid':planid},function(mydata){
$('.countcravers:eq('+index+')').html(' '+mydata+' cravers');
});*/	
}

});
     
});

    
});



$('.uncraveplan').each(function(index, element) {

$('.uncraveplan:eq('+index+')').click(function(e) {
planid = $('.planids:eq('+index+')').val();
$.post('../snippets/removecraver.php',{'planid':planid},function(data)
{

$('.cravebox:eq('+index+')').html('<i style="display:none;" title="Uncrave This Plan" style="color:#F3565D;" class="cravestyle fa fa-camera uncraveplan"> crave </i> <i title="Crave this Plan" class="cravestyle fa fa-camera craveplan"> crave </i><script src="../myscript/home.js"></script>');
/*$.get('../snippets/countcravers.php',{'planid':planid},function(mydata){
$('.countcravers:eq('+index+')').html(' '+mydata+' cravers');
});*/	


});
     
});

    
});

/*setInterval(function(){
$('.timeline-block').each(function(index, element) {
planid = $('.planids:eq('+index+')').val();
    
});

},3000)*/


});