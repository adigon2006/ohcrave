var busy = false;
var limit = 10
var offset = 0;
 
function displayRecords(lim, off) {
        $.ajax({
          type: "GET",
          async: false,
          url: "../snippets/gethomeplanbypage.php",
          data: "limit=" + lim + "&offset=" + off,
          cache: false,
          beforeSend: function() {
            $("#loader_message").html("").hide();
      $.loader('close'); 
          },
          success: function(html) {
            $("#activehomeplans").append(html);
          $.loader('close');  
            if (html == "") {
             $.loader('close');  
            } else {
    //             $.loader({
    // className:"blue-with-image-2",
    // content:''
    // });
            }
            window.busy = false;
 
          }
        });
}

$(document).ready(function() {
if (busy == false) {
  busy = true;
  // start to load the first set of data
  displayRecords(limit, offset);
}
});


$(document).ready(function() {
 
$(window).scroll(function() {
          // make sure u give the container id of the data to be loaded in.
          if ($(window).scrollTop() + $(window).height() > $("#activehomeplans").height() && !busy) {
            busy = true;
            offset = limit + offset;
 
            displayRecords(limit, offset);
 
          }
});
 
});



