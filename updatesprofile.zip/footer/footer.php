   <div class="footer">
          &copy; <?php echo date('Y'); ?> Ohcrave Copyright All Right Reserved
        </div>

 <script src="../js/jquery.min.js"></script> 

<script src="../myscript/menuupdate.js">
    </script>