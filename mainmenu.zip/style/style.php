<link rel="stylesheet" href="../css/purple.css"/>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:600' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Droid+Sans:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="../css/style.css"/>
<link rel="stylesheet" href="../css/font.css"/>
<link href="../css/jquery.loader.css" rel="stylesheet" />