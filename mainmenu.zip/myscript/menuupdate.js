$(document).ready(function(e) {
setInterval(function(e)
{
$.get('../snippets/getnoofactiveplans.php',"",function(data){$('#activeplansno').html(data);});	
},3000);

setInterval(function(e)
{
$.get('../snippets/getnoofbox.php',"",function(data){$('#boxno').html(data);});	
},3000);


setInterval(function(e)
{
$.get('../snippets/getnoofnotifications.php',"",function(data){$('#notificationno').html(data);});	
},3000);
    
});