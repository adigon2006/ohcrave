<script id="chat-window-template" type="text/x-handlebars-template">
//         <div class="panel panel-default">
//             <div class="panel-heading" data-toggle="chat-collapse" data-target="#chat-bill">
//                 <a href="#" class="close"><i class="fa fa-times"></i></a>
//                 <a href="#">
//                     <img src="{{ user_image }}" width="40" class="pull-left">
//                     <span class="contact-name">{{user}}</span>
//                 </a>
//             </div>
//             <div class="panel-body" id="chat-bill">
//                 <div class="media">
//                     <div class="pull-left">
//                         <img src="{{ user_image }}" width="25" class="img-circle" alt="people" />
//                     </div>
//                     <div class="media-body">
//                         <span class="message">Feeling Groovy?</span>
//                     </div>
//                 </div>
//                 <div class="media right">
//                     <div class="pull-right">
//                         <img src="{{ user_image }}" width="25" class="img-circle" alt="people" />
//                     </div>
//                     <div class="media-body">
//                         <span class="message">Yep.</span>
//                     </div>
//                 </div>
//                 <div class="media">
//                     <div class="pull-left">
//                         <img src="{{ user_image }}" width="25" class="img-circle" alt="people" />
//                     </div>
//                     <div class="media-body">
//                         <span class="message">This chat window looks amazing.</span>
//                     </div>
//                 </div>
//                 <div class="media right">
//                     <div class="pull-right">
//                         <img src="{{ user_image }}" width="25" class="img-circle" alt="people" />
//                     </div>
//                     <div class="media-body">
//                         <span class="message">Thanks!</span>
//                     </div>
//                 </div>
//             </div>
//             <input type="text" class="form-control" placeholder="Type message..." />
//         </div>
    </script>
