
<div class="row">
                <div class="col-md-6">

                    <div class="panel panel-default profile-user-box">
                        <h4>Page does not exist</h4>
                    </div>
                    <!--Friends -->
                  
                </div>
               <?php include_once '../ads/temp1.php'; ?>
<!-- <div class="panel panel-default">
                <div class="panel-heading panel-heading-gray">
                    <i class="fa fa-bookmark"></i> Bookmarks
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-4">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <a href="#" class="h5 margin-none">Climb a Mountain</a>
                                    <div class="text-muted">
                                        <small><i class="fa fa-calendar"></i> 24/10/2014</small>
                                    </div>
                                </div>
                                <a href="#">
                                    <img src="../images/place1-full.jpg" alt="image" class="img-responsive" />
                                </a>
                                <div class="panel-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor impedit ipsum laborum maiores tempore veritatis....</p>
                                    <div>
                                        <a href="#" class="btn btn-primary btn-xs pull-right">read</a>
                                        <a href="#" class="text-muted"> <i class="fa fa-comments"></i> 6</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="panel panel-default">
                                <div class="panel-body text-center">
                                    <a href="#" class="h5 margin-none">Vegetarian Pizza</a>
                                    <div class="text-muted">
                                        <small><i class="fa fa-calendar"></i> 24/10/2014</small>
                                    </div>
                                    <div class="rating">
                                        <span class="star"></span>
                                        <span class="star filled"></span>
                                        <span class="star filled"></span>
                                        <span class="star filled"></span>
                                        <span class="star filled"></span>
                                    </div>
                                </div>
                                <a href="#">
                                    <img src="../images/food1-full.jpg" alt="image" class="img-responsive" />
                                </a>
                                <div class="panel-body">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor impedit ipsum laborum maiores tempore veritatis....</p>
                                    <div>
                                        <a href="#" class="btn btn-primary btn-xs pull-right">read</a>
                                        <a href="#" class="text-muted"> <i class="fa fa-comments"></i> 6</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="panel panel-default">
                                <div class="panel-body">
                                    <a href="#" class="btn btn-success btn-xs pull-right"><i class="fa fa-check-circle"></i></a>
                                    <a href="#" class="h5">Win a Holiday</a>
                                    <div class="text-muted">
                                        <small><i class="fa fa-calendar"></i> 24/10/2014</small>
                                    </div>
                                </div>
                                <a href="#">
                                    <img src="images/place2-full.jpg" alt="image" class="img-responsive" />
                                </a>
                                <div class="panel-body">
                                    <ul class="icon-list block bordered">
                                        <li><i class="fa fa-calendar fa-fw"></i> <a href="#">1 Week</a>
                                        </li>
                                        <li><i class="fa fa-users fa-fw"></i> <a href="#"> 2 People</a>
                                        </li>
                                        <li><i class="fa fa-map-marker fa-fw"></i> <a href="#">Miami, FL, USA</a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> -->
 <script src="../js/vendor.min.js"></script>
<script src="../myscript/publicprofilefollow.js"></script>